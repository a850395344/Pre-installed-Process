"use strict";

const XLSX = require("xlsx");
const pdfParse = require("pdf-parse");

function clean(value) {
  return String(value == null ? "" : value).replace(/\u0000/g, "").trim();
}

function number(value) {
  if (value == null || value === "") return null;
  const n = Number(String(value).replace(/[,，]/g, "").trim());
  return Number.isFinite(n) ? n : null;
}

// 表头只做语义匹配，不依赖固定列号；兼容空格、大小写和常见中英文写法。
function normalizeHeader(value) {
  return clean(value)
    .replace(/[\s\u3000]+/g, "")
    .replace(/[：:（）()]/g, "")
    .toLowerCase();
}

function headerBase(value) {
  return normalizeHeader(value).split(/[\/|]/)[0];
}

function resolveColumn(header, aliases) {
  const wanted = new Set((aliases || []).map(normalizeHeader));
  return header.findIndex((h) => {
    const full = normalizeHeader(h);
    return wanted.has(full) || wanted.has(headerBase(h));
  });
}

function resolvePreferredColumn(header, predicate, fallbackAliases = []) {
  const preferred = header.findIndex((h) => predicate(normalizeHeader(h)));
  return preferred >= 0 ? preferred : resolveColumn(header, fallbackAliases);
}

function cleanPlaceholder(value) {
  const v = clean(value);
  return ["-", "—", "–", "/"].includes(v) ? "" : v;
}

function resolveColumns(header, definitions) {
  const columns = {};
  const missing = [];
  const duplicateHeaders = [];
  const seen = new Map();
  header.forEach((h, i) => {
    const key = normalizeHeader(h);
    if (!key) return;
    if (seen.has(key)) duplicateHeaders.push({ header: clean(h), indexes: [seen.get(key), i] });
    else seen.set(key, i);
  });
  for (const [key, def] of Object.entries(definitions)) {
    const index = resolveColumn(header, def.aliases);
    columns[key] = index;
    if (def.required && index < 0) missing.push(def.label || key);
  }
  return { columns, missing, duplicateHeaders };
}

function detectBlankCandidateHeaders(header, rows, dataStart, knownColumnIndexes) {
  const known = new Set(knownColumnIndexes || []);
  return header.map((h, i) => clean(h)).filter((h, i) => h && !known.has(i) && !rows.slice(dataStart).some((r) => clean((r || [])[i])));
}

function cell(row, index) {
  return index >= 0 ? row[index] : "";
}

function sheetToRows(wb, sheetName) {
  const ws = wb.Sheets[sheetName];
  if (!ws) return [];
  return XLSX.utils.sheet_to_json(ws, { header: 1, defval: "", raw: true });
}

function findHeaderRow(rows, predicate) {
  for (let i = 0; i < Math.min(rows.length, 30); i++) {
    if (predicate(rows[i])) return i;
  }
  return -1;
}

function detectConfigHeaders(header, rows, dataStart, knownColumnIndexes, dataRowPredicate = null) {
  const configs = [];
  const known = new Set(knownColumnIndexes || []);
  for (let i = 0; i < header.length; i++) {
    const label = clean(header[i]);
    if (!label || known.has(i)) continue;
    let hasSelected = false;
    let invalidValues = 0;
    for (let r = dataStart; r < rows.length; r++) {
      const row = rows[r] || [];
      if (dataRowPredicate && !dataRowPredicate(row)) continue;
      const value = clean(row[i]);
      if (!value) continue;
      if (/^x$/i.test(value)) hasSelected = true;
      else invalidValues += 1;
    }
    // 配置列允许任意长度/语言的表头；数据特征必须是 X/x 或空白，且至少选中过一次。
    if (hasSelected && invalidValues === 0) configs.push({ code: label, index: i });
  }
  return configs;
}

function configMarkerIndex(header) {
  return header.findIndex((h) => ["配置", "config", "configuration"].includes(headerBase(h)));
}

function configCandidateIndexes(header, knownColumnIndexes) {
  const marker = configMarkerIndex(header);
  const known = new Set(knownColumnIndexes || []);
  return header.map((h, i) => i).filter((i) => !known.has(i) && (marker < 0 || i > marker));
}

function parseMBOM(buffer, filename) {
  const wb = XLSX.read(buffer, { type: "buffer" });
  const sheetName =
    wb.SheetNames.find((name) => /sheet/i.test(name) && !/wire|线/i.test(name)) ||
    wb.SheetNames[0];
  const rows = sheetToRows(wb, sheetName);
  const headerRowIndex = findHeaderRow(rows, (r) => {
    const h = r.map(headerBase);
    return h.includes("看板号3") && h.includes("图纸号") && h.includes("看板号1");
  });
  if (headerRowIndex < 0) {
    throw new Error(`MBOM文件(${filename})未找到标准表头，请确认是MBOM/Cutting导线表。`);
  }

  const header = rows[headerRowIndex].map(clean);
  const resolved = resolveColumns(header, {
    w3: { aliases: ["看板号3", "看板3", "W3"], label: "看板号3", required: true },
    w2: { aliases: ["看板号2", "看板2", "W2"], label: "看板号2", required: true },
    w1: { aliases: ["看板号1", "看板1", "W1"], label: "看板号1", required: true },
    material: { aliases: ["材料名称", "物料名称"], label: "材料名称", required: true },
    drawingId: { aliases: ["图纸号", "图号"], label: "图纸号", required: true },
    customerNo: { aliases: ["客户号", "客户料号"], label: "客户号" },
    jettyNo: { aliases: ["捷翼号"], label: "捷翼号" },
    spec: { aliases: ["规格"], label: "规格", required: true },
    color: { aliases: ["颜色", "线色"], label: "颜色", required: true },
    length: { aliases: ["下料长度_绞合后", "下料长度绞合后"], label: "下料长度_绞合后" },
    lengthPre: { aliases: ["下料长度_绞合前", "下料长度绞合前"], label: "下料长度_绞合前" },
    unit: { aliases: ["单位"], label: "单位" },
    terminal1: { aliases: ["端子1", "端子一", "A端端子", "A端-端子"], label: "端子1", required: true },
    terminal1Jetty: { aliases: ["端子1捷翼号", "端子1料号"], label: "端子1捷翼号" },
    seal1: { aliases: ["雨塞1", "防水塞1", "密封件1", "A端防水塞", "A端-防水塞"], label: "雨塞1" },
    terminal2: { aliases: ["端子2", "端子二", "B端端子", "B端-端子"], label: "端子2", required: true },
    seal2: { aliases: ["雨塞2", "防水塞2", "密封件2", "B端防水塞", "B端-防水塞"], label: "雨塞2" },
    housing1: { aliases: ["护套1", "Housing1", "A端Housing"], label: "护套1", required: true },
    position1: { aliases: ["孔位1", "端子孔位1", "A端孔位"], label: "孔位1", required: true },
    housing2: { aliases: ["护套2", "Housing2", "B端Housing"], label: "护套2", required: true },
    position2: { aliases: ["孔位2", "端子孔位2", "B端孔位"], label: "孔位2", required: true }
  });
  const c = resolved.columns;
  const missing = resolved.missing.filter((label) => !["下料长度_绞合后", "下料长度_绞合前"].includes(label));
  if (c.length < 0 && c.lengthPre < 0) missing.push("下料长度_绞合后/绞合前");
  const knownColumns = Object.values(c).filter((i) => i >= 0);
  const candidateIndexes = configCandidateIndexes(header, knownColumns);
  const configs = detectConfigHeaders(
    header,
    rows,
    headerRowIndex + 1,
    knownColumns.concat(header.map((_, i) => candidateIndexes.includes(i) ? i : -1).filter((i) => i >= 0 && !candidateIndexes.includes(i))),
    (row) => !!(clean(cell(row, c.w1)) || clean(cell(row, c.drawingId)))
  ).filter((cfg) => candidateIndexes.includes(cfg.index));
  const wires = [];
  let currentW3 = "";
  let currentW2 = "";

  for (let i = headerRowIndex + 1; i < rows.length; i++) {
    const r = rows[i];
    const w1 = cleanPlaceholder(cell(r, c.w1));
    const drawing = clean(cell(r, c.drawingId));
    if (!w1 && !drawing) continue;

    if (cleanPlaceholder(cell(r, c.w3))) {
      // 新的W3块开始；若该行没有W2，则为W3直挂W1，必须清空上一W2
      currentW3 = cleanPlaceholder(cell(r, c.w3));
      currentW2 = cleanPlaceholder(cell(r, c.w2));
    } else if (cleanPlaceholder(cell(r, c.w2))) {
      // W2块开始；在W3区域内继续保留当前W3，在W3区域外currentW3保持为空
      currentW2 = cleanPlaceholder(cell(r, c.w2));
    }

    const configMap = {};
    for (const cfg of configs) {
      configMap[cfg.code] = /^x$/i.test(clean(cell(r, cfg.index)));
    }

    const wire = {
      w3: currentW3,
      w2: currentW2,
      w1,
      material: clean(cell(r, c.material)),
      drawingId: drawing,
      customerNo: clean(cell(r, c.customerNo)),
      jettyNo: clean(cell(r, c.jettyNo)),
      spec: clean(cell(r, c.spec)),
      color: clean(cell(r, c.color)),
      length: number(cell(r, c.length)) ?? number(cell(r, c.lengthPre)),
      lengthSource: number(cell(r, c.length)) != null ? "下料长度_绞合后" : number(cell(r, c.lengthPre)) != null ? "下料长度_绞合前（绞后缺失回退）" : "",
      lengthUnit: clean(cell(r, c.unit)) || "mm",
      terminal1: clean(cell(r, c.terminal1)),
      terminal1Jetty: clean(cell(r, c.terminal1Jetty)),
      seal1: clean(cell(r, c.seal1)),
      terminal2: clean(cell(r, c.terminal2)),
      seal2: clean(cell(r, c.seal2)),
      housing1: clean(cell(r, c.housing1)) || "",
      position1: clean(cell(r, c.position1)),
      housing2: clean(cell(r, c.housing2)) || "",
      position2: clean(cell(r, c.position2)),
      config: configMap,
      configCodes: Object.keys(configMap).filter((k) => configMap[k]),
      status: "已读取"
    };
    wires.push(wire);
  }

  const nonEmptyConfigs = configs
    .map((c) => c.code)
    .filter((code) => wires.some((w) => w.config[code]));

  return {
    sheetName,
    filename,
    header,
    configs: nonEmptyConfigs,
    configHeaders: configs,
    columnMap: c,
    missingHeaders: missing,
    duplicateHeaders: resolved.duplicateHeaders,
    blankCandidateHeaders: detectBlankCandidateHeaders(header, rows, headerRowIndex + 1, Object.values(c).filter((i) => i >= 0)),
    wires,
    rowCount: wires.length,
    uniqueW1: new Set(wires.map((w) => w.w1).filter(Boolean)).size
  };
}

function parseSpecialWireSheet(rows, headerIndex, sheetName) {
  const header = rows[headerIndex].map(clean);
  const findCol = (name) => header.findIndex((h) => h.includes(name));
  const lineCol = findCol("线号");
  if (lineCol < 0) return [];
  const moduleNoCol = findCol("线束零件号");
  const moduleNameCol = findCol("线束零件名称");
  const drawingCol = lineCol;
  const customerCol = findCol("电线");
  const colorCol = findCol("颜色");
  const lengthCol = findCol("理论长度");
  const h1Col = findCol("A端Housing");
  const t1Col = findCol("A端-端子");
  const s1Col = findCol("A端-防水塞");
  const h2Col = findCol("B端Housing");
  const t2Col = findCol("B端-端子");
  const s2Col = findCol("B端-防水塞");
  const posIndices = header.map((h, i) => [h, i]).filter(([h]) => h.includes("孔位")).map(([, i]) => i);
  const p1Col = posIndices[0] >= 0 ? posIndices[0] : -1;
  const p2Col = posIndices[1] >= 0 ? posIndices[1] : -1;
  const knownColumns = [
    lineCol, moduleNoCol, moduleNameCol, customerCol, colorCol, lengthCol,
    h1Col, t1Col, s1Col, h2Col, t2Col, s2Col, ...posIndices
  ].filter((i) => i >= 0);
  const candidateIndexes = configCandidateIndexes(header, knownColumns);
  const configs = detectConfigHeaders(header, rows, headerIndex + 1, knownColumns, (row) => !!clean(row[lineCol]))
    .filter((cfg) => candidateIndexes.includes(cfg.index));

  const wires = [];
  for (let i = headerIndex + 1; i < rows.length; i++) {
    const r = rows[i];
    const lineNo = clean(r[lineCol]);
    if (!lineNo) continue;
    const configMap = {};
    for (const cfg of configs) {
      configMap[cfg.code] = clean(r[cfg.index]).toUpperCase() === "X";
    }
    wires.push({
      w3: "",
      w2: "",
      w1: lineNo,
      material: clean(r[moduleNameCol]) || "特殊线束",
      drawingId: lineNo,
      customerNo: customerCol >= 0 ? clean(r[customerCol]) : "",
      jettyNo: "",
      spec: "",
      color: colorCol >= 0 ? clean(r[colorCol]) : "",
      length: lengthCol >= 0 ? number(r[lengthCol]) : null,
      lengthUnit: "mm",
      terminal1: t1Col >= 0 ? clean(r[t1Col]) : "",
      seal1: s1Col >= 0 ? clean(r[s1Col]) : "",
      housing1: h1Col >= 0 ? clean(r[h1Col]) : "",
      position1: p1Col >= 0 ? clean(r[p1Col]) : "",
      terminal2: t2Col >= 0 ? clean(r[t2Col]) : "",
      seal2: s2Col >= 0 ? clean(r[s2Col]) : "",
      housing2: h2Col >= 0 ? clean(r[h2Col]) : "",
      position2: p2Col >= 0 ? clean(r[p2Col]) : "",
      config: configMap,
      configCodes: Object.keys(configMap).filter((k) => configMap[k]),
      status: "已读取",
      sourceSheet: sheetName
    });
  }
  return wires;
}

function parseEBOM(buffer, filename) {
  const wb = XLSX.read(buffer, { type: "buffer" });
  const allSheets = wb.SheetNames;
  let mainSheet = null;
  let mainHeaderIndex = -1;

  for (const name of allSheets) {
    const rows = sheetToRows(wb, name);
    const idx = findHeaderRow(rows, (r) =>
      r.some((v) => headerBase(v) === "模块号") &&
      r.some((v) => headerBase(v) === "材料名称")
    );
    if (idx >= 0) {
      mainSheet = name;
      mainHeaderIndex = idx;
      break;
    }
  }

  if (!mainSheet) {
    throw new Error(`EBOM文件(${filename})未找到主EBOM表头。`);
  }

  const rows = sheetToRows(wb, mainSheet);
  const header = rows[mainHeaderIndex].map(clean);
  const resolved = resolveColumns(header, {
    moduleNo: { aliases: ["模块号"], label: "模块号", required: true },
    moduleName: { aliases: ["模块名称"], label: "模块名称" },
    materialName: { aliases: ["材料名称", "物料名称"], label: "材料名称", required: true },
    description: { aliases: ["Description", "描述"], label: "描述" },
    drawingId: { aliases: ["图纸号", "图号"], label: "图纸号", required: true },
    jettyNo: { aliases: ["捷翼号生产", "捷翼号/Jetty No.生产"], label: "捷翼号（生产）", required: true },
    spn: { aliases: ["厂家号生产", "厂家号/SPN生产"], label: "厂家号（生产）" },
    supplier: { aliases: ["厂家生产", "厂家/Supplier生产"], label: "厂家（生产）" },
    designQty: { aliases: ["图纸用量", "设计用量"], label: "图纸用量", required: true },
    processAllowance: { aliases: ["工艺余量"], label: "工艺余量" },
    totalQty: { aliases: ["总用量"], label: "总用量" },
    unit: { aliases: ["单位"], label: "单位", required: true },
    unitPrice: { aliases: ["单价"], label: "单价" },
    totalPrice: { aliases: ["价格汇总", "总价"], label: "价格汇总" },
    copperWeight: { aliases: ["理论铜重", "铜重"], label: "理论铜重" },
    notes: { aliases: ["备注", "说明"], label: "备注" }
  });
  const c = resolved.columns;
  c.jettyNo = resolvePreferredColumn(header, (h) => h.includes("捷翼号") && h.includes("生产"), ["捷翼号"]);
  c.spn = resolvePreferredColumn(header, (h) => h.includes("厂家号") && h.includes("生产"), ["厂家号"]);
  c.supplier = resolvePreferredColumn(header, (h) => h.includes("厂家") && !h.includes("厂家号") && h.includes("生产"), ["厂家", "供应商"]);
  const productionLabels = new Set(["捷翼号（生产）", "厂家号（生产）", "厂家（生产）"]);
  const missing = resolved.missing.filter((label) => !productionLabels.has(label));
  if (c.jettyNo < 0) missing.push("捷翼号（生产）");
  const materials = [];

  for (let i = mainHeaderIndex + 1; i < rows.length; i++) {
    const r = rows[i];
    const materialName = clean(cell(r, c.materialName));
    if (!materialName) continue;
    materials.push({
      moduleNo: clean(cell(r, c.moduleNo)),
      moduleName: clean(cell(r, c.moduleName)),
      materialName,
      description: clean(cell(r, c.description)),
      drawingId: clean(cell(r, c.drawingId)),
      jettyNo: clean(cell(r, c.jettyNo)),
      spn: clean(cell(r, c.spn)),
      supplier: clean(cell(r, c.supplier)),
      designQty: number(cell(r, c.designQty)),
      processAllowance: number(cell(r, c.processAllowance)),
      totalQty: number(cell(r, c.totalQty)),
      unit: clean(cell(r, c.unit)),
      unitPrice: number(cell(r, c.unitPrice)),
      totalPrice: number(cell(r, c.totalPrice)),
      copperWeight: number(cell(r, c.copperWeight)),
      notes: clean(cell(r, c.notes))
    });
  }

  // Extra sheets containing wire-level tables in EBOM workbook are collected separately.
  const specialSheets = [];
  const specialWires = [];
  for (const name of allSheets) {
    if (name === mainSheet) continue;
    const rows2 = sheetToRows(wb, name);
    const idx = findHeaderRow(rows2, (r) =>
      r.some((v) => normalizeHeader(v).includes("线束零件号") || normalizeHeader(v) === "线号")
    );
    if (idx >= 0) {
      const wires = parseSpecialWireSheet(rows2, idx, name);
      specialSheets.push({
        sheetName: name,
        header: rows2[idx].map(clean),
        rowCount: rows2.slice(idx + 1).filter((r) => r.some((c) => clean(c) !== "")).length,
        wireCount: wires.length
      });
      specialWires.push(...wires);
    }
  }

  return {
    filename,
    sheetName: mainSheet,
    header,
    columnMap: c,
    missingHeaders: missing,
    duplicateHeaders: resolved.duplicateHeaders,
    materials,
    rowCount: materials.length,
    specialSheets,
    specialWires
  };
}

function parseStandardHours(buffer, filename) {
  const wb = XLSX.read(buffer, { type: "buffer" });
  const sheetName = wb.SheetNames[0];
  const rows = sheetToRows(wb, sheetName);
  const headerRowIndex = findHeaderRow(rows, (r) =>
    r.some((v) => /labor\s*time|标准工时/i.test(clean(v)))
  );
  if (headerRowIndex < 0) {
    throw new Error(`标准工时文件(${filename})未找到“标准工时”列。`);
  }

  const header = rows[headerRowIndex].map(clean);
  const resolved = resolveColumns(header, {
    process: { aliases: ["工序", "Process"], label: "工序", required: true },
    activity: { aliases: ["工作要素说明", "工作要素", "Activity"], label: "工作要素说明", required: true },
    comments: { aliases: ["描述", "说明", "Description"], label: "描述", required: true },
    clockStart: { aliases: ["动作开始", "开始", "Start"], label: "动作开始", required: true },
    clockStop: { aliases: ["动作结束", "结束", "Stop"], label: "动作结束", required: true },
    time: { aliases: ["标准工时", "labor time"], label: "标准工时", required: true },
    unit: { aliases: ["单位", "Unit"], label: "单位", required: true }
  });
  const c = resolved.columns;
  const entries = [];
  let currentProcess = "";
  for (let i = headerRowIndex + 1; i < rows.length; i++) {
    const r = rows[i];
    const activity = clean(cell(r, c.activity));
    const comments = clean(cell(r, c.comments));
    const time = number(cell(r, c.time));
    if (!activity && !comments) continue;
    if (clean(cell(r, c.process)) === "Porcess" || clean(cell(r, c.process)).includes("工序")) continue;

    const proc = clean(cell(r, c.process));
    if (proc) currentProcess = proc;

    entries.push({
      process: currentProcess,
      activity: activity || currentProcess,
      comments,
      clockStart: clean(cell(r, c.clockStart)),
      clockStop: clean(cell(r, c.clockStop)),
      time,
      unit: clean(cell(r, c.unit)) || "pc"
    });
  }

  return {
    filename,
    sheetName,
    header,
    columnMap: c,
    missingHeaders: resolved.missing,
    duplicateHeaders: resolved.duplicateHeaders,
    entries,
    rowCount: entries.length
  };
}

async function parsePDF(buffer, filename) {
  const data = await pdfParse(buffer);
  const text = data.text || "";
  const keywords = [
    "护套", "Housing", "波纹管", "胶带", "橡胶件", "Grommet", "屏蔽", "双绞",
    "节点", "分支", "支架", "卡钉", "扎带", "标签", "保险丝", "继电器",
    "后盖", "盲塞", "防水", "密封"
  ];
  const keywordHits = {};
  for (const kw of keywords) {
    const re = new RegExp(kw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g");
    const m = text.match(re);
    if (m) keywordHits[kw] = m.length;
  }

  return {
    filename,
    numPages: data.numpages || 1,
    textLength: text.length,
    text,
    keywordHits,
    status: "已提取文本；版面/图形关系仍需人工或后续AI核对"
  };
}

module.exports = {
  clean,
  number,
  parseMBOM,
  parseEBOM,
  parseStandardHours,
  parsePDF
};
